## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## ----setup--------------------------------------------------------------------
# library(lame)

## -----------------------------------------------------------------------------
# # Load example data (list of networks over time)
# data(example_networks)  # This would be your data
# 
# # Fit a basic LAME model
# fit <- lame(
#   Y = example_networks,
#   R = 2,                # 2 latent dimensions
#   family = "binary",    # Binary networks
#   nscan = 5000,        # Number of MCMC iterations
#   burn = 500,          # Burn-in period
#   odens = 25           # Output density
# )
# 
# # View results
# summary(fit)
# plot(fit)

## -----------------------------------------------------------------------------
# # Fit model with dynamic effects
# fit_dynamic <- lame(
#   Y = example_networks,
#   R = 2,
#   dynamic_ab = TRUE,   # Dynamic additive effects
#   dynamic_uv = TRUE,   # Dynamic multiplicative effects
#   family = "binary",
#   nscan = 10000,
#   burn = 1000,
#   odens = 25
# )
# 
# # Visualize temporal evolution
# ab_plot(fit_dynamic, plot_type = "trajectory")
# uv_plot(fit_dynamic, time_point = "all")

## -----------------------------------------------------------------------------
# # Fit model with covariates
# fit_cov <- lame(
#   Y = example_networks,
#   Xdyad = dyadic_covariates,    # Dyadic covariates
#   Xrow = sender_covariates,      # Sender covariates
#   Xcol = receiver_covariates,    # Receiver covariates
#   R = 2,
#   family = "binary",
#   nscan = 10000
# )

## -----------------------------------------------------------------------------
# # Fit bipartite model
# fit_bip <- lame(
#   Y = bipartite_networks,
#   mode = "bipartite",
#   R_row = 3,           # 3 dimensions for row nodes
#   R_col = 2,           # 2 dimensions for column nodes
#   family = "binary",
#   nscan = 10000
# )
# 
# # Access the interaction matrix
# fit_bip$G  # Rectangular matrix mapping row to column latent spaces

## -----------------------------------------------------------------------------
# # Plot GOF statistics
# gof_plot(fit)
# 
# # Access GOF statistics directly
# gof_stats <- fit$GOF

## -----------------------------------------------------------------------------
# # Trace plots for convergence assessment
# trace_plot(fit)
# 
# # Effective sample sizes
# fit$ESS

## -----------------------------------------------------------------------------
# fit_custom <- lame(
#   Y = example_networks,
#   prior = list(
#     Sab0 = diag(2),     # Prior scale for variance
#     eta0 = 10,          # Prior degrees of freedom
#     rho_ab_mean = 0.8,  # AR(1) mean for dynamic effects
#     rho_ab_sd = 0.1     # AR(1) standard deviation
#   ),
#   nscan = 10000
# )

## -----------------------------------------------------------------------------
# fit_sym <- lame(
#   Y = undirected_networks,
#   symmetric = TRUE,
#   R = 2,
#   family = "normal",
#   nscan = 10000
# )

