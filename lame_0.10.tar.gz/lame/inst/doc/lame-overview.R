## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "",
  fig.width = 6,
  fig.height = 4,
  dpi = 200,
  out.width = "100%",
  fig.align = "center",
  dev = "png" 
)

## ----setup, include=FALSE-----------------------------------------------------
library(lame)
library(ggplot2)

# Load the TIES data
data("vignette_data")


## ----message=FALSE, warning=FALSE---------------------------------------------
# Fit the AME model for binary data
fit <- lame(
  Y = Y,                    
  Xdyad = Xdyad,           # dyadic covariates
  Xrow = Xrow,             # sender covariates
  Xcol = Xcol,             # receiver covariates 
  family = "binary",       # Binary  model
  rvar = TRUE,             # sender random effects
  cvar = TRUE,             # receiver random effects
  dcor = TRUE,            # Dyadic correlation
  R = 2,                   # Multiplicative effects dimension
  symmetric = FALSE,       # Directed networks
  burn = 100,              # Burn-in iterations
  nscan = 500,             # Post-burn-in iterations
  odens = 25,              # Output density
  print = FALSE,           # Suppress iteration output
  plot = FALSE             # Suppress real-time plots
)


## -----------------------------------------------------------------------------
summary(fit)

## ----fig.alt="MCMC trace plots and density plots showing convergence and posterior distributions of regression coefficients"----
names(fit)
trace_plot(fit, params = "beta")

## ----fig.width=8, fig.height=6, dpi=100, dev="png", fig.alt="Goodness of fit plots comparing observed network statistics to posterior predictive distributions across time periods"----
gof_plot(fit) 

## ----fig.width=8, fig.height=6, dpi=100, dev="png", fig.alt="Network visualization showing multiplicative effects latent space positions of countries in the sanctions network"----

# Network plot showing multiplicative effects
uv_plot(fit) +
  ggtitle("Sanctions Network - Multiplicative Effects") +
  theme_minimal() +
  theme(
    legend.position='none',
    axis.text=element_blank(),
    axis.title=element_blank()
  )


