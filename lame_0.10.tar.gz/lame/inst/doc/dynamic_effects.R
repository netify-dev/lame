## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
prior_custom <- list(
  rho_uv_mean = 0.95,    # Higher persistence for UV
  rho_uv_sd = 0.05,      # Tighter prior
  sigma_uv_shape = 3,    # Different variance prior
  sigma_uv_scale = 2
)

## -----------------------------------------------------------------------------
library(lame)

# Simulate longitudinal network data
set.seed(6886)
n <- 25  # actors (reduced for faster vignette building)
T <- 5   # time periods (reduced for faster vignette building)

# Generate networks (example with binary data)
Y_list <- list()
for(t in 1:T) {
  Y_t <- matrix(rbinom(n*n, 1, 0.1), n, n)
  diag(Y_t) <- NA
  # Add actor labels (required for lame function)
  rownames(Y_t) <- colnames(Y_t) <- paste0("Actor", 1:n)
  Y_list[[t]] <- Y_t
}

# Fit model with dynamic effects (reduced iterations for vignette)
fit_dynamic <- lame(
  Y = Y_list,
  R = 2,                # 2-dimensional latent space
  dynamic_uv = TRUE,    # Dynamic latent factors
  dynamic_ab = TRUE,    # Dynamic additive effects
  family = "binary",
  burn = 100,          # Reduced for vignette (use 1000+ in practice)
  nscan = 500,         # Reduced for vignette (use 5000+ in practice)
  odens = 25,
  print = FALSE,       # Suppress output for vignette
  plot = FALSE         # Suppress plots for vignette
)

## -----------------------------------------------------------------------------
# Plot latent positions (last time point)
uv_plot(fit_dynamic, plot_type = "snapshot")

# Plot sender effects 
ab_plot(fit_dynamic, effect = "sender")

# Plot trace of parameters
trace_plot(fit_dynamic)

## -----------------------------------------------------------------------------
# Static model
fit_static <- lame(Y_list, R = 2, family = "binary", 
                   burn = 100, nscan = 400, odens = 20, 
                   print = FALSE, plot = FALSE)

# Dynamic UV only
fit_uv <- lame(Y_list, R = 2, dynamic_uv = TRUE, family = "binary",
               burn = 100, nscan = 400, odens = 20,
               print = FALSE, plot = FALSE)

# Dynamic AB only  
fit_ab <- lame(Y_list, R = 2, dynamic_ab = TRUE, family = "binary",
               burn = 100, nscan = 400, odens = 20,
               print = FALSE, plot = FALSE)

# Full dynamic
fit_full <- lame(Y_list, R = 2, dynamic_uv = TRUE, dynamic_ab = TRUE, family = "binary",
                 burn = 100, nscan = 400, odens = 20,
                 print = FALSE, plot = FALSE)

# Compare GOF statistics
if(!is.null(fit_static$GOF) && !is.null(fit_full$GOF)) {
  cat("Static model GOF (sample):\n")
  print(head(fit_static$GOF))
  cat("\nDynamic model GOF (sample):\n")  
  print(head(fit_full$GOF))
}

