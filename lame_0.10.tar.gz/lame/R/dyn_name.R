#' @useDynLib lame, .registration = TRUE
#' @import Rcpp
NULL