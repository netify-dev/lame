# Package initialization handled automatically by Rcpp

#' @importFrom grDevices devAskNewPage
#' @importFrom stats aggregate dnorm
#' @importFrom utils head
NULL