## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "",
  fig.width = 6,
  fig.height = 4,
  dpi = 200,
  out.width = "100%",
  fig.align = "center",
  dev = "png" 
)

## ----setup, include=FALSE-----------------------------------------------------
library(lame)
library(ggplot2)

# Load the TIES data
data("vignette_data")


## ----message=FALSE, warning=FALSE---------------------------------------------
# Fit the AME model for binary data
fit <- lame(
  Y = Y,                    
  Xdyad = Xdyad,           # dyadic covariates
  Xrow = Xrow,             # sender covariates
  Xcol = Xcol,             # receiver covariates 
  family = "bin",          # Binary  model
  rvar = TRUE,             # sender random effects
  cvar = TRUE,             # receiver random effects
  dcor = TRUE,            # Dyadic correlation
  R = 2,                   # Multiplicative effects dimension
  symmetric = FALSE,       # Directed networks
  burn = 100,              # Burn-in iterations
  nscan = 500,             # Post-burn-in iterations
  odens = 25,              # Output density
  print = FALSE,           # Suppress iteration output
  plot = FALSE             # Suppress real-time plots
)


## -----------------------------------------------------------------------------
summary(fit)

## -----------------------------------------------------------------------------
names(fit)
paramPlot(fit$BETA)

## ----fig.width=8, fig.height=6, dpi=100, dev="png"----------------------------
gofPlot(fit$GOF, FALSE) 

## ----fig.width=8, fig.height=6, dpi=100, dev="png"----------------------------
gofPlot_long(fit$GOF, type= "actual", symmetric = FALSE)

## ----fig.width=8, fig.height=6, dpi=100, dev="png"----------------------------
gofPlot_long(fit$GOF, type= "deviation", symmetric = FALSE)

## ----fig.width=8, fig.height=6, dpi=100, dev="png"----------------------------

# Network plot for 1995
ggCirc(Y=Y[[3]], U=fit$U, V=fit$V) +
  ggtitle("Sanctions Network - 1995") +
  theme_minimal() +
  theme(
    legend.position='none',
    axis.text=element_blank(),
    axis.title=element_blank()
  )


